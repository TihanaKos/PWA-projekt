PNW-PROGRAMIRANJE WEB APLIKACIJA-PROJEKT
-cilj: izrada funkcionalnog portala za vijesti pomoću php-a,html-a,css-a te baze podataka
-kako bi mogli otvoriti stra
- projekt: izrada funkcionalnog web središta pomoću html, php, css, jQuery i povezanosti na bazu i SQLom

- nakon što se preuzeli projekt potrebno ga je raspakirati iz ZIP datoteke te premijestiti u "htdocs" (za XAMPP) ili "www" (za WAMP) direktorij. Nakon toga potrebno je u phpMyAdmin importati bazu podataka koja se nalazi u projektu pod nazivom (pnw-projket).. Zatim otvorite web preglednik i idite na http://localhost/Stern
