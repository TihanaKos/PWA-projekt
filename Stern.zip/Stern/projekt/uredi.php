<?php
include 'connect.php';
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obrada forme za uređivanje
    $id = $_POST['id'];
    $naslov = $_POST['naslov'];
    $sazetak = $_POST['sazetak'];
    $tekst = $_POST['tekst'];
    $kategorija = $_POST['kategorija'];

    $query = "UPDATE clanci SET naslov='$naslov', sazetak='$sazetak', tekst='$tekst', kategorija='$kategorija' WHERE ID=$id";
    mysqli_query($conn, $query) or die('Error updating database.');

    header("Location: administracija.php");
    exit();
} else {
    // Prikaz forme za uređivanje
    $id = $_GET['id'];
    $query = "SELECT * FROM clanci WHERE ID=$id";
    $result = mysqli_query($conn, $query);
    $clanak = mysqli_fetch_assoc($result);
}
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <title>Uredi članak</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<header>
    <nav class="navbar navbar-expand-sm justify-content-center">
        <img id="STERN" src="img/logo.png" class="navbar-brand"/>
        <div class="container-fluid justify-content-center">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="indeks.php">HOME</a></li>
                <li class="nav-item"><a class="nav-link" href="kategorija.php?kategorije=politik">POLITIK</a></li>
                <li class="nav-item"><a class="nav-link" href="kategorija.php?kategorije=gesundheit">GESUNDHEIT</a></li>
                <?php if (isset($_SESSION['username'])): ?>
                    <li class="nav-item"><a class="nav-link" href="unos.php">ARTIKEL HINZUFÜGEN</a></li>
                    <li class="nav-item"><a class="nav-link" href="logout.php">LOGOUT</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="login.php">LOGIN</a></li>
                    <li class="nav-item"><a class="nav-link" href="registracija.php">REGISTRIERUNG</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
</header>
<div  class="container mt-5">
    <h1>Uredi članak</h1>
    <form class="login-section" action="uredi.php" method="post" class="edit-form">
        <input type="hidden" name="id" value="<?php echo $clanak['ID']; ?>">
        <div class="mb-3">
            <label for="naslov" class="form-label">Naslov:</label>
            <input type="text" id="naslov" name="naslov" class="form-control" value="<?php echo $clanak['naslov']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="sazetak" class="form-label">Sažetak:</label>
            <textarea id="sazetak" name="sazetak" class="form-control" required><?php echo $clanak['sazetak']; ?></textarea>
        </div>
        <div class="mb-3">
            <label for="tekst" class="form-label">Sadržaj:</label>
            <textarea id="tekst" name="tekst" class="form-control" required><?php echo $clanak['tekst']; ?></textarea>
        </div>
        <div class="mb-3">
            <label for="kategorija" class="form-label">Kategorija:</label>
            <input type="text" id="kategorija" name="kategorija" class="form-control" value="<?php echo $clanak['kategorija']; ?>" required>
        </div>
        <div class="mb-3">
            <input type="submit" value="Ažuriraj" class="btn btn-primary">
        </div>
    </form>
</div>
<footer>
    <p>Tehničko Veleučilište Zagreb - PNW Projekt - Tihana Kos - 2024.</p>
</footer>
</body>
</html>
