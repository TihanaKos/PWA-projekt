<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Stern</title>
    <meta name="description" content="projekt iz kolegija Programiranje web aplikacija">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="author" content="Tihana Kos">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<header>
    <nav class="navbar navbar-expand-sm">
    <img id="STERN" src="img/logo.png"/>            
    <div class="container-fluid">
        <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" href="indeks.php">HOME</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="kategorija.php?kategorije=politik">POLITIK</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="kategorija.php?kategorije=gesundheit">GESUNDHEIT</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="login.php">LOGIN</a>
        </li>
        </ul>
    </div>
    </nav>
</header>
<div class="tijelo">
    <?php
        include 'connect.php'; 
        define('URL', 'img/'); 
        $idKategorije = mysqli_real_escape_string($conn, $_GET['kategorije']); // Saniranje unosa
    ?>
    <section class="container politik">
        <div class="row">
            <h1 class="col-lg-12 col-12"><?php
            if ($idKategorije === 'politik'){
                echo "POLITIK";
            }
            else if ($idKategorije === 'gesundheit'){
                echo "GESUNDHEIT";
            }
            ?></h1>
        </div>
        <?php
            $query = "SELECT * FROM clanci WHERE kategorija='$idKategorije'";
            $result = mysqli_query($conn, $query) or die("Error: " . mysqli_error($conn)); // Detaljnija greška
            while($row = mysqli_fetch_array($result)) {
                echo '<section class="row clanci">';
                echo '<div class="col">';
                echo '<img src="' . URL . $row['slika'] . '" class="img-fluid">';
                echo '</div>';
                echo "<article class='col'><br>";
                echo '<p><h2><a href="article.php?id='.$row['ID'].'">';
                echo $row['naslov'];
                echo '</a></h2><br>';
                echo "</p></article>";
                echo '</section>';
            }
        ?>
    </section>
</div>
<footer class="container-fluid">
    <p>
    Tehničko Veleučilište Zagreb - PWA Projekt - Tihana Kos - 2024.
    </p>
</footer>
</body>
</html>
