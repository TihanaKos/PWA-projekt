<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Stern</title>
    <meta name="description" content="projekt iz kolegija Programiranje web aplikacija">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="author" content="Tihana Kos">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<header>
    <nav class="navbar navbar-expand-sm justify-content-center">
        <img id="STERN" src="img/logo.png" class="navbar-brand"/>            
        <div class="container-fluid justify-content-center">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="indeks.php">HOME</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="kategorija.php?kategorije=politik">POLITIK</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="kategorija.php?kategorije=gesundheit">GESUNDHEIT</a>
                </li>
                <?php if (isset($_SESSION['username'])): ?>
                <li class="nav-item">
                    <a class="nav-link" href="unos.php">ARTIKEL HINZUFÜGEN</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">LOGOUT</a>
                </li>
                <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link" href="login.php">LOGIN</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="registracija.php">REGISTRIERUNG</a>
                </li>
                <?php endif; ?>
                
            </ul>
        </div>
    </nav>
</header>
<div class="tijelo">
    <div class="container">
        <section class="row">
            <h1 class="col-lg-12 col-12">POLITIK</h1>
        </section>
        <div class="row">
        <?php
            include 'connect.php'; 
            define('URL', 'img/'); 

            $query = "SELECT * FROM clanci WHERE arhiva=0 AND kategorija='politik' LIMIT 3";
            $result = mysqli_query($conn, $query);
            while($row = mysqli_fetch_array($result)) {
                echo "<article class='col-md-4 col-12'><br>";
                echo "<img src='" . URL. $row['slika'] . "' class='img-fluid'><br>";
                echo "<p><br>";
                echo '<a href="article.php?id='.$row['ID'].'">';
                echo $row['naslov'];
                echo '</a>';
                echo "</p><br>";
                echo "</article><br>";
            }     
        ?>
        </div>
    </div>
    <div class="container">
        <section class="row">
            <h1 class="col-lg-12 col-12">GESUNDHEIT</h1>
        </section>
        <div class="row">
        <?php
            $query = "SELECT * FROM clanci WHERE arhiva=0 AND kategorija='gesundheit' LIMIT 3";
            $result = mysqli_query($conn, $query);
            while($row = mysqli_fetch_array($result)) {
                echo "<article class='col-md-4 col-12'><br>";
                echo "<img src='" . URL. $row['slika'] . "' class='img-fluid'><br>";
                echo "<p><br>";
                echo '<a href="article.php?id='.$row['ID'].'">';
                echo $row['naslov'];
                echo '</a>';
                echo "</p><br>";
                echo "</article><br>";
            }     
        ?>
        </div>
    </div>
</div>
<footer class="container-fluid">
    <p>
        Tehničko Veleučilište Zagreb - PWA Projekt - Tihana Kos - 2024.
    </p>
</footer>
</body>
</html>
