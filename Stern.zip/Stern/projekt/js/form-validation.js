function validateForm() {
    var title = document.getElementById('title').value;
    var about = document.getElementById('about').value;
    var content = document.getElementById('content').value;
    var category = document.getElementById('category').value;
    var picToUpload = document.getElementById('picToUpload').value;

    if (title.length < 5 || title.length > 30) {
        alert("Titel muss zwischen 5 und 30 Zeichen lang sein");
        return false;
    }
    if (about.length < 10 || about.length > 100) {
        alert("Zusammenfassung muss zwischen 10 und 100 Zeichen lang sein");
        return false;
    }
    if (content === "") {
        alert("Inhalt darf nicht leer sein");
        return false;
    }
    if (category === "") {
        alert("Kategorie muss ausgewählt werden");
        return false;
    }
    if (picToUpload === "") {
        alert("Bild muss ausgewählt werden");
        return false;
    }
    return true;
}
