<?php
include 'connect.php';
session_start();

if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    $query = "INSERT INTO korisnici (korisnicko_ime, lozinka, email, razina) VALUES ('$username', '$password', '$email', 0)";
    $result = mysqli_query($conn, $query) or die("Error querying database: " . mysqli_error($conn));

    header("Location: login.php");
    exit();
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Registrierung</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<header>
    <nav class="navbar navbar-expand-sm justify-content-center">
        <img id="STERN" src="img/logo.png" class="navbar-brand"/>            
        <div class="container-fluid justify-content-center">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="indeks.php">HOME</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="kategorija.php?kategorije=politik">POLITIK</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="kategorija.php?kategorije=gesundheit">GESUNDHEIT</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php">LOGIN</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="registracija.php">REGISTRIERUNG</a>
                </li>
                <?php if (isset($_SESSION['username']) && $_SESSION['level'] == 1): ?>
                <li class="nav-item">
                    <a class="nav-link" href="administracija.php">VERWALTUNG</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="unos.html">ARTIKEL HINZUFÜGEN</a>
                </li>
                <?php endif; ?>
                <?php if (isset($_SESSION['username'])): ?>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">LOGOUT</a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
</header>
<section class="registration-section">
    <h1>Registrieren</h1>
    <form class="registration-form" method="post" action="registracija.php">
        <label for="username">Benutzername:</label>
        <input type="text" id="username" name="username" required>
        <label for="password">Passwort:</label>
        <input type="password" id="password" name="password" required>
        <label for="email">E-Mail:</label>
        <input type="email" id="email" name="email" required>
        <input type="submit" name="submit" value="Registrieren">
    </form>
</section>
<footer class="container-fluid">
    <p>
    Tehničko Veleučilište Zagreb - PWA Projekt - Tihana Kos - 2024.
    </p>
</footer>
</body>
</html>
