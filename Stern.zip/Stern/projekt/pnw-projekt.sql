-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 13, 2024 at 02:11 PM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pnw-projekt`
--

-- --------------------------------------------------------

--
-- Table structure for table `clanci`
--

DROP TABLE IF EXISTS `clanci`;
CREATE TABLE IF NOT EXISTS `clanci` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `datum` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `naslov` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sazetak` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tekst` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slika` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategorija` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `arhiva` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clanci`
--

INSERT INTO `clanci` (`ID`, `datum`, `naslov`, `sazetak`, `tekst`, `slika`, `kategorija`, `arhiva`) VALUES
(1, '10.06.2024.', 'Ein Journalist von Al-Dschasira, dem einflussreichsten Sender im', 'Dieser Artikel untersucht die aktuellen Herausforderungen, mit denen die Europäische Union konfrontiert ist, einschließlich Themen wie Migration, wirtschaftliche Ungleichheit und zunehmender Nationalismus.', 'Berg, Seilbahn und Gärten aus aller Welt\r\n\r\nUnter den Linden oder am Brandenburger Tor in die U5 einsteigen und dann einfach immer in Richtung Osten fahren. Am Kienberg aussteigen – und schon ist die Welt eine andere. Zwar ist der Berliner Berg, der zum Teil aus Trümmerschutt besteht, mit 102 Metern nicht besonders hoch – aber die Aussicht ist trotzdem einmalig. Von oben fährt seit 2017 eine für die Internationale Gartenschau gebaute, 1,5 Kilometer lange Seilbahn direkt zu den Gärten der Welt in Mahlsdorf. Zusammen mit diesem einmaligen Park mit zehn sehenswerten Themengärten wurde das IGA-Gelände rund um den Kienberg zum Erlebnispark.\r\n\r\nEin Tal, zwei Schlösser, drei Flüsse\r\n\r\n seinem eigenen Haus soll ein Al-Dschasira-Journalist drei Geiseln für die Hamas festgehalten haben. Das berichtet die israelische Armee (IDF). Nach acht Monaten konnten israelische Soldaten am Samstag insgesamt vier Geiseln befreien, drei sollen sich im Haus des Journalisten befunden haben: Almog Meir Jan (22), Andrey Kozlov (27) und Shlomi Ziv (40). Im Haus seiner Familie soll der freie Journalist die drei Männer monatelang festgehalten haben. Eine weitere Geisel, die 26-jährige Noa Argamani, wurde in einem Haus 200 Meter weiter entdeckt. Neben dem TV-Sender soll er auch für „The Palestine Chronicle“ gearbeitet haben.Israels Armee zeigte sich empört und wütend. „Der „Journalist“ Abdallah A. war ein Hamas-Terrorist, der Almog, Andrey und Shlomi im Haus seiner Familie in Nuseirat als Geiseln festhielt“, schreibt die Armee. „Keine Presseweste kann ihn für die Verbrechen, die er begangen hat, entschuldigen.“ Zudem fragen sie den Nachrichtensender: „Was macht dieser Terrorist auf eurer Website?“', 'befreite.jpg', 'Politik', 0),
(2, '10.06.2024.', '„Bevölkerung ist durch mit dieser Regierung“, sagt Ex-SPD-Chef G', 'Sigmar Gabriel sieht die Ampel-Koalition nach dem schlechten Wahlergebnis als irreparabel beschädigt. Derweil lobt AfD-Spitzenkandidat Maximilian Krah die Gewinne seiner Partei – „und es ist nur der Anfang“, sagt er. Alle News im Liveticker.', 'Mit Blick auf das historisch schlechte Abschneiden der SPD bei der Europawahl hat deren früherer Vorsitzender Sigmar Gabriel die Parteispitze scharf angegriffen. Sie müsste sich fragen, welchen Anteil sie „an diesem Debakel“ hat, sagte er im „Tagesspiegel“. Die SPD fiel auf 13,9 Prozent (14 Sitze) und erzielte damit ihr schlechtestes Ergebnis. „Mit 14 Prozent hat niemand unbestritten den Anspruch, die SPD zu führen“, sagte er.\r\n\r\nDie Ampel-Koalition sieht Gabriel irreparabel beschädigt. „Die Bevölkerung ist durch mit dieser Regierung“, sagte er weiter. Das Wahlergebnis sei „eine schallende Ohrfeige für die Ampel-Koalition.“Der Zentralrat der Juden zeigt sich besorgt über das starke Ergebnis von populistischen Parteien bei der Europawahl in Deutschland. „Es sollte allen demokratischen Kräften zu denken geben, dass bei der Wahl zum Europäischen Parlament in Deutschland rechts- und linkspopulistische Parteien ein Fünftel der Wählerstimmen bekommen haben“, sagte Zentralratspräsident Josef Schuster am Montag.\r\n\r\nAnzeige\r\n\r\n\r\nDas sei nicht nur Protest. „Dass gerade die AfD mit ihren eindeutigen Bezügen zu rechtsextremem Gedankengut und Verbindungen ihrer Spitzenkandidaten zu diktatorischen Regimen ein solches Ergebnis erreichen konnte, beunruhigt mich sehr.“', 'politicar.jpg', 'Politik', 0),
(3, '10.06.2024.', '400 Wahlkreise ausgezählt – Alle Ergebnisse und Grafiken im Über', 'Europa hat ein neues Parlament gewählt. Laut dem Endergebnis liegt in Deutschland die Union deutlich vorn. Die AfD verzeichnet gegenüber 2019 deutliche Zugewinne, die Grünen verlieren klar. WELT gibt einen Überblick zur Europawahl mit allen Daten und Grafiken.', 'Die Union hat die Europawahl in Deutschland mit großem Abstand gewonnen – vor der AfD, die zweitstärkste Kraft wurde. Wie die Bundeswahlleiterin um 4:16 Uhr nach Auszählung aller 400 Kreise auf ihrer Homepage mitteilte, legten CDU und CSU zusammen auf 30,0 Prozent zu. Die AfD verbesserte sich deutlich auf 15,9 Prozent. Von den in Berlin regierenden Koalitionsparteien fiel die SPD auf 13,9 Prozent und damit ihr schlechtestes Ergebnis bei einer bundesweiten Wahl zurück.Die Grünen stürzten noch stärker ab auf 11,9 Prozent, die FDP erlitt mit 5,2 Prozent leichte Einbußen. Das neu gegründete linke Bündnis Sahra Wagenknecht (BSW) kam aus dem Stand auf 6,2 Prozent, die Linke auf 2,7 Prozent. Auch die Parteien Freie Wähler, Volt, Die Partei, ÖDP, Tierschutzpartei und Familienpartei errangen Mandate. Die Wahlbeteiligung in Deutschland hat mit 64,8 Prozent einen neuen Höchstwert seit der Wiedervereinigung erreicht.', 'eu.jpg', 'Politik', 0),
(4, '10.06.2024.', 'Diese Diät soll für ein besonders langes Leben sorgen', 'Herzkreislauf, Krebs, Lungenerkrankungen – die sogenannte Planetary Health Diät soll das Risiko für diese Krankheiten deutlich senken und gleichzeitig gut für den Planeten sein. Wie diese Ernährung aussieht und wie sie wirkt.', 'iel Obst und Gemüse, Hülsenfrüchte und Nüsse, dafür wenig Fleisch, Milch und Zucker: Das steht auf dem Speiseplan der sogenannten Planetary Health Diet, die die Gesundheit des Menschen und des Planeten gleichermaßen schützen soll. Ein Forschungsteam um Walter Willett von der US-amerikanischen Harvard T.H. Chan Schol of Public Health kommt nun zu dem Schluss, dass diese Ernährung nicht nur ökologisch nachhaltig ist, sondern tatsächlich auch das Risiko deutlich senkt, früh zu sterben.Wie die Forscher im Fachblatt „American Journal of Clinical Nutrition“ berichten, betrafen die positiven Auswirkungen der Ernährungsweise alle damit zusammenhängenden in der westlichen Welt bedeutsamen Todesursachen. Jene Menschen, die sich besonders an diese Form der Ernährung hielten, hatten ein 23 Prozent niedrigeres Risiko für einen frühen Tod als jene, die diesen Empfehlungen am wenigsten folgten. Das Risiko für einen frühen Tod durch Herz-Kreislauf-Erkrankungen war demnach um 14 Prozent verringert, durch Krebs um 10 Prozent, durch neurodegenerative Erkrankungen um 28 Prozent und durch Atemwegserkrankungen um 47 Prozent.\r\n\r\nGerade dieses Resultat, das bei Männern und Frauen ähnlich ausgeprägt war, sei am auffälligsten gewesen, schreibt die Gruppe. Zwar sei ein Zusammenhang zwischen Ernährung und Atemwegserkrankungen - vor allem zur Chronisch Obstruktiven Lungenerkrankung (COPD) - schon häufiger ermittelt worden, die genauen Mechanismen müssten aber noch geklärt werden.', 'dijeta.jpg', 'Gesundheit', 0),
(5, '10.06.2024.', 'Höheres Verletzungsrisiko durch Menstruationszyklus?', 'Athletinnen vermuten, dass ihre Periode die sportliche Leistung beeinflusst. Jedoch stimmt ihre Wahrnehmung nicht mit den Messungen überein, wie eine Studie nun bestätigt. Eine Phase im Zyklus könnte Frauen allerdings anfälliger für Verletzungen machen.', 'Messung und Selbstwahrnehmung stimmen nicht überein: Während der Menstruation schneiden Frauen in kognitiven Tests besser ab – halten ihre Leistung aber selbst für schlechter. In einer britischen Studie reagierten Teilnehmerinnen in dieser Phase des Menstruationszyklus auf Tests zu Reaktion, Aufmerksamkeit und räumlicher Vorstellung schneller und lagen seltener falsch.Schlechter schnitten die Frauen dagegen während der sogenannte Lutealphase ab – also in den etwa zwei Wochen zwischen Eisprung und Menstruation. Dadurch könne in dieser Phase das Verletzungsrisiko beim Sport steigen, vermutet das Team um Flaminia Ronca vom University College London in der Zeitschrift „Neuropsychologia“.\r\n\r\n„Es überrascht, dass die Teilnehmerinnen während der Menstruation besser abschnitten“, wird Ronca in einer Mitteilung der Universität zitiert. „Das weckt Zweifel daran, was Frauen – und möglicherweise auch die Gesellschaft allgemein – über ihre Fähigkeiten während dieser besonderen Phase annehmen.“\r\n\r\nAuf die Idee zu der Studie kam das Forschungsteam durch Gespräche mit Fußballerinnen darüber, ob der Menstruationszyklus ihre Leistung beeinflussen und sich auch auf ihr Verletzungsrisiko auswirken könnte. Um dies zu prüfen, untersuchte das Team jedoch keine physiologischen Faktoren wie etwa Körpertemperatur, Kraft oder Kontrolle über die Muskeln. Stattdessen ließen sie insgesamt 241 Teilnehmende – darunter 96 Männer – diverse kognitive Tests absolvieren, und zwar im Abstand von zwei Wochen.', 'sportas.jpg', 'Gesundheit', 0),
(6, '10.06.2024.', 'Das Mädchen mit der Schmetterlingshaut und wie ihr eine neue Beh', 'Ein Gendefekt macht bei manchen Menschen die Haut so empfindlich wie die Flügel eines Schmetterlings. Schon wenn sie zu fest angefasst werden, können sie schmerzhafte Verletzungen davontragen. Eine Therapie aus den USA schürt Hoffnungen, auch bei diesem kleinen Mädchen.', 'Wenn die kleine Käthe aufs Laufrad steigt und losdüst, dann haften an ihr die besorgten Blicke ihrer Eltern. Denn jeder noch so kleine Sturz kann für das Mädchen aus dem westsächsischen Zwickau erhebliche Folgen haben. „Käthe ist wie ein rohes Ei zu behandeln“, erklärt Mutter Katharina Hofmann. Die Vierjährige leidet an der unheilbaren Schmetterlingskrankheit. Was nahezu poetisch klingt, bedeutet für Betroffene häufige Schmerzen, aufwendige Pflege und viele Einschränkungen im Alltag. Manche haben auch nur ein kurzes Leben vor sich.Ärzte sprechen von Epidermolysis bullosa (EB) – eine seltene Erkrankung, die auf Veränderungen in den Genen zurückgeht. Manche Menschen tragen eine Mutation in sich, erkranken aber nicht. Doch können sie diese an ihre Kinder vererben. So wie Katharina Hofmann und ihr Mann Frank. Der Fehler im Erbgut führt dazu, dass der Zusammenhalt der Hautschichten geschwächt ist. Die Folge: Schon kleinste Verletzungen, Reibungen oder Druck führen zu Blasen und offenen Wunden. Auch Schleimhäute können betroffen sein und so das Essen erschweren und schmerzhafte innere Verletzungen hervorrufen.', 'dijete.jpg', 'Gesundheit', 0),
(53, '12.06.2024.', 'Bundesnetzagentur legt Regeln zur Bewertung von Handynetzen vor', 'Künftig sollen Verbraucher ihren Vertrag kündigen können, wenn das Handynetz schlecht ist. Die Bundesnetzagentur hat nun ein entsprechendes Messtool angekündigt.', 'Künftig sollen Verbraucherinnen und Verbraucher bei schlechtem Handynetz die Zahlungen an ihren Mobilfunkanbieter mindern oder auch ihren Vertrag außerordentlich kündigen können. Ein entsprechender Rechtsanspruch gilt schon seit 2021. Jetzt hat die Bundesnetzagentur Regeln zur Bewertung von Handynetzen vorgelegt, da bislang eine konkrete Definition der schlechten Leistung fehlte. Behördenchef Klaus Müller hat ein Messtool angekündigt, mit dem die Kunden die Qualität im Mobilfunk \"prüfen und nachweisen\" können sollen.\r\n\r\n\r\n\"Mit dem geplanten Messtool werden Verbraucherinnen und Verbraucher prüfen und nachweisen können, ob die Qualität im Mobilfunk dem entspricht, was im Vertrag vereinbart worden ist\", sagte Müller. Ein genaues Datum dafür nannte er noch nicht.\r\n\r\nAnbieter müssen in ihren Mobilfunktarifen einen geschätzten Maximalwert für die Datenübertragung angeben. Wenn ein Handynutzer auf dem Land von diesem Wert weniger als zehn Prozent bekommt, soll er künftig Anspruch auf Minderung haben – wie hoch die genau ist, muss er mit seinem Anbieter oder gerichtlich klären. In Gebieten mit mittlerer Bevölkerungsdichte liegt die Schwelle bei 15 Prozent und in Gebieten mit hoher Bevölkerungsdichte bei 25 Prozent. Handynutzer müssen für einen Nachweis 30 Messungen an fünf verschiedenen Tagen durchführen.\r\nNach dem Vorschlag der Bundes', 'primjer.jpg', 'Politik', 0);

-- --------------------------------------------------------

--
-- Table structure for table `korisnici`
--

DROP TABLE IF EXISTS `korisnici`;
CREATE TABLE IF NOT EXISTS `korisnici` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `ime` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `prezime` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `korisnicko_ime` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lozinka` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `razina` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `korisnicko_ime` (`korisnicko_ime`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `korisnici`
--

INSERT INTO `korisnici` (`ID`, `ime`, `prezime`, `korisnicko_ime`, `lozinka`, `email`, `razina`) VALUES
(1, 'admin', 'admin', 'admin12', 'admin', '', 1),
(23, '', '', 'Tihana', 'tk', 'Tihana@tvz.hr', 0),
(24, '', '', 'Tihana12', 'tk12', 'Tihana@tvz.hr', 0),
(26, '', '', 't', 'k', 'tk@tkhr', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
