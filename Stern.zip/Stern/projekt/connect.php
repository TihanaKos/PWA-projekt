<?php
$servername = "localhost";
$username = "root";  
$password = ""; 
$dbname = "pnw-projekt";  

// Kreiranje konekcije
$conn = new mysqli($servername, $username, $password, $dbname);

// Provjera konekcije
if ($conn->connect_error) {
    die("Konekcija nije uspjela: " . $conn->connect_error);
}

?>
