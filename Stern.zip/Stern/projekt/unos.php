<?php
include 'connect.php';
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $about = $_POST['about'];
    $content = $_POST['content'];
    $category = $_POST['category'];
    $date = date('d.m.Y.');
    $archive = isset($_POST['archive']) ? 1 : 0;
    $picture = $_FILES['picToUpload']['name'];
    $target_dir = 'img/' . $picture;
    move_uploaded_file($_FILES['picToUpload']['tmp_name'], $target_dir);

    $query = "INSERT INTO clanci (datum, naslov, sazetak, tekst, slika, kategorija, arhiva) VALUES ('$date', '$title', '$about', '$content', '$picture', '$category', '$archive')";
    mysqli_query($conn, $query) or die('Error querying database.');

    header("Location: administracija.php");
    exit();
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Article</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<header>
    <nav class="navbar navbar-expand-sm justify-content-center">
        <img id="STERN" src="img/logo.png" class="navbar-brand"/>
        <div class="container-fluid justify-content-center">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="indeks.php">HOME</a></li>
                <li class="nav-item"><a class="nav-link" href="kategorija.php?kategorije=politik">POLITIK</a></li>
                <li class="nav-item"><a class="nav-link" href="kategorija.php?kategorije=gesundheit">GESUNDHEIT</a></li>
                <?php if (isset($_SESSION['username'])): ?>
                    <li class="nav-item"><a class="nav-link" href="unos.php">ARTIKEL HINZUFÜGEN</a></li>
                    <li class="nav-item"><a class="nav-link" href="logout.php">LOGOUT</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="login.php">LOGIN</a></li>
                    <li class="nav-item"><a class="nav-link" href="registracija.php">REGISTRIERUNG</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
</header>
<div class="container mt-5">
    <h1>Verwaltung</h1>
    <form action="unos.php" method="post" enctype="multipart/form-data" class="admin-form">
        <div class="mb-3">
            <label for="title" class="form-label">Titel:</label>
            <input type="text" id="title" name="title" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="about" class="form-label">Zusammenfassung:</label>
            <textarea id="about" name="about" class="form-control" required></textarea>
        </div>
        <div class="mb-3">
            <label for="content" class="form-label">Inhalt:</label>
            <textarea id="content" name="content" class="form-control" required></textarea>
        </div>
        <div class="mb-3">
            <label for="category" class="form-label">Kategorie:</label>
            <input type="text" id="category" name="category" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="picToUpload" class="form-label">Bild:</label>
            <input type="file" name="picToUpload" id="picToUpload" class="form-control" required>
        </div>
        <div class="form-check mb-3">
            <input type="checkbox" name="archive" id="archive" class="form-check-input">
            <label for="archive" class="form-check-label">Archivieren</label>
        </div>
        <div class="mb-3">
            <input type="submit" value="Artikel hinzufügen" class="btn btn-primary">
        </div>
    </form>
</div>
</body>
</html>
