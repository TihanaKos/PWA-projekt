<?php
include 'connect.php';
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'];
$query = "DELETE FROM clanci WHERE ID=$id";
mysqli_query($conn, $query) or die('Error deleting from database.');

header("Location: administracija.php");
exit();
?>
