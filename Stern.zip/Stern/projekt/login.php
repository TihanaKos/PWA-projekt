<?php
include 'connect.php';
session_start();

if (isset($_POST['submit'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $query = "SELECT * FROM korisnici WHERE korisnicko_ime='$username' AND lozinka='$password'";
    $result = mysqli_query($conn, $query) or die("Error querying database: " . mysqli_error($conn));

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['username'] = $row['korisnicko_ime'];
        $_SESSION['level'] = $row['razina'];

        if ($row['razina'] == 1) {
            header("Location: administracija.php");
        } else {
            header("Location: indeks.php");
        }
        exit();
    } else {
        $error_message = "Neispravno korisničko ime ili lozinka.";
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <meta name="description" content="projekt iz kolegija Programiranje web aplikacija">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="author" content="Tihana Kos">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<header>
    <nav class="navbar navbar-expand-sm">
        <img id="STERN" src="img/logo.png"/>            
        <div class="container-fluid">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="indeks.php">HOME</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="kategorija.php?kategorije=politik">POLITIK</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="kategorija.php?kategorije=gesundheit">GESUNDHEIT</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php">LOGIN</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="registracija.php">REGISTRIERUNG</a>
                </li>
                <?php if (isset($_SESSION['username']) && $_SESSION['level'] == 1): ?>
                <li class="nav-item">
                    <a class="nav-link" href="administracija.php">VERWALTUNG</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="unos.html">ARTIKEL HINZUFÜGEN</a>
                </li>
                <?php endif; ?>
                <?php if (isset($_SESSION['username'])): ?>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">LOGOUT</a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
</header>
<div class="tijelo">
    <section  class="container login">
        <h1>WILLKOMMEN</h1>
        <form method="POST" action="login.php">
            <div class="mb-3">
                <label for="username" class="form-label">Unesite svoje korisničko ime:</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Unesite svoju lozinku:</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" name="submit" class="btn btn-primary">Podnesi</button>
        </form>
        <?php if (isset($error_message)): ?>
            <p class="error"><?php echo $error_message; ?></p>
        <?php endif; ?>
    </section>
    <div  class="login-section" ></div>
</div>
<footer class="container-fluid">
    <p>
    Tehničko Veleučilište Zagreb - PWA Projekt - Tihana Kos - 2024.
    </p>
</footer>
</body>
</html>
