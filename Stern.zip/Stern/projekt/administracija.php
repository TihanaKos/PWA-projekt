<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['username']) || $_SESSION['level'] != 1) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $about = $_POST['about'];
    $content = $_POST['content'];
    $category = $_POST['category'];
    $date = date('d.m.Y.');
    $archive = isset($_POST['archive']) ? 1 : 0;
    $picture = $_FILES['picToUpload']['name'];
    $target_dir = 'img/' . $picture;
    move_uploaded_file($_FILES['picToUpload']['tmp_name'], $target_dir);

    $query = "INSERT INTO clanci (datum, naslov, sazetak, tekst, slika, kategorija, arhiva) VALUES ('$date', '$title', '$about', '$content', '$picture', '$category', '$archive')";
    mysqli_query($conn, $query) or die('Error querying database.');
    header("Location: administracija.php");
    exit();
}

$query = "SELECT * FROM clanci";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Verwaltung</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<header>
    <nav class="navbar navbar-expand-sm">
        <img id="STERN" src="img/logo.png"/>
        <div class="container-fluid">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="indeks.php">HOME</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="kategorija.php?kategorije=politik">POLITIK</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="kategorija.php?kategorije=gesundheit">GESUNDHEIT</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php">LOGIN</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="registracija.php">REGISTRIERUNG</a>
                </li>
                <?php if (isset($_SESSION['username']) && $_SESSION['level'] == 1): ?>
                <li class="nav-item">
                    <a class="nav-link" href="administracija.php">VERWALTUNG</a>
                </li>
                
                <?php endif; ?>
                <?php if (isset($_SESSION['username'])): ?>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">LOGOUT</a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
</header>

<div class="tijelo">
    <h1>Verwaltung</h1>
    <form class="admin-form" action="administracija.php" method="post" enctype="multipart/form-data">
        <label for="title">Titel:</label><br>
        <input type="text" id="title" name="title" required><br>
        <label for="about">Zusammenfassung:</label><br>
        <textarea id="about" name="about" required></textarea><br>
        <label for="content">Inhalt:</label><br>
        <textarea id="content" name="content" required></textarea><br>
        <label for="category">Kategorie:</label><br>
        <input type="text" id="category" name="category" required><br>
        <label for="picToUpload">Bild:</label><br>
        <input type="file" id="picToUpload" name="picToUpload" required><br>
        <label for="archive">Archivieren:</label>
        <input type="checkbox" id="archive" name="archive"><br>
        <input type="submit" value="Artikel hinzufügen">
    </form>
    <h2>Artikel Liste</h2>
    <div class="article-list">
        <table>
            <tr>
                <th>Titel</th>
                <th>Zusammenfassung</th>
                <th>Datum</th>
                <th>Aktionen</th>
            </tr>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?php echo $row['naslov']; ?></td>
                    <td><?php echo $row['sazetak']; ?></td>
                    <td><?php echo $row['datum']; ?></td>
                    <td>
                        <a href="uredi.php?id=<?php echo $row['ID']; ?>">Uredi</a>
                        <a href="obrisi.php?id=<?php echo $row['ID']; ?>">Obriši</a>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>
</div>

<footer class="container-fluid">
    <p>
    Tehničko Veleučilište Zagreb - PWA Projekt - Tihana Kos - 2024.
    </p>
</footer>
</body>
</html>

<?php
mysqli_close($conn);
?>
